void computeNext(double** x0, double** x, int size_x, int size_y, double dt, double hx, double hy, double* diff, double k0);

void initValues(double** x0, int size_x, int size_y, double temp1, double temp2);
